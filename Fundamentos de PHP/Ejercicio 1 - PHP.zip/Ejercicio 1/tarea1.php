<?php

    echo "Con función echo podemos imprimir directamente varias cadenas a la vez. <br>";

    print_r("Con la función print solo podremos imprimir una cadena cada vez que sea llamada.");




